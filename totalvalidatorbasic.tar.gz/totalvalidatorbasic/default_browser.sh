#!/bin/sh
#
# Copyright 2017, Total Validator. All rights reserved.
# Use is subject to the terms of the licence.
#

#
# Change this line to point to your browser
# ensure you keep the $* part at the end though!
#
/usr/bin/firefox $*
