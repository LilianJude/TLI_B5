/*
  Copyright (c) Total Validator.
  All Rights Reserved.
*/
function toggleMenu() {
  var lhbox = document.getElementById("lhbox");
  var middle = document.getElementById("middle");
  var toggle = document.getElementById("dropdown-toggle");
  if (window.getComputedStyle(lhbox, null).getPropertyValue("width") == "0px") {
    lhbox.style.width = "185px";
    middle.style.marginLeft = "195px";
    middle.style.width = "initial";
    toggle.style.display = "none";
  }
  else {
    lhbox.style.width = "0px";
    middle.style.marginLeft = "0px";
    middle.style.width = "100%";
    toggle.style.display = "inline";
  }
}
