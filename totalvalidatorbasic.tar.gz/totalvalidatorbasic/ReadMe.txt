------------------------------------------------------------
                    TOTAL VALIDATOR BASIC
------------------------------------------------------------
INTRODUCTION

Total Validator allows you to perform many different
validations on your web pages in one go, rather than using
several tools to achieve the same thing. It can simultaneously
validate your HTML, check that pages are accessible,
run a spell check, and check for broken links.

------------------------------------------------------------
INSTALLING/UNINSTALLING

You must have Java 7.0 or later installed to run Total Validator.

Windows: To install, run the .exe file you downloaded, overwriting
any previous installation. Uninstall from the Windows control panel
like any other Windows program.

macOS: To install, drag the TotalValidator icons into your
Applications folder. To uninstall, drag these icons into your
Trash. If any messages appear when you first try to run Total
Validator, please read the FAQ for solutions:
https://www.totalvalidator.com/help/faq.html#osx

Linux: To install, copy the .tar.gz file you downloaded into
the directory of your choice and run the following command
to create a 'totalvalidator' directory which contains the
application:

  # tar xvfz totalvalidator.tar.gz

Use total_validator.sh to start. To display the results in your
browser you may have to amend default_browser.sh. To uninstall,
delete the totalvalidator directory.

------------------------------------------------------------
COPYRIGHT

Copyright 2017, Total Validator. All rights reserved.
Use is subject to the terms of the licence.

------------------------------------------------------------
