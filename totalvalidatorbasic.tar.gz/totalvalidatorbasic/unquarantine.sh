#!/bin/sh
#
# Copyright 2017, Total Validator. All rights reserved.
# Use is subject to the terms of the licence.
#
find $1 | xargs xattr -d com.apple.quarantine
